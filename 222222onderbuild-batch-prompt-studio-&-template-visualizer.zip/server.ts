import express from "express";
import path from "path";
import http from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Server-side Gemini API client lazy initializer
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured in environment variables.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Health route
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// 1. API Batch Generation (gemini-3.6-flash)
app.post("/api/generate-batch", async (req, res) => {
  try {
    const { category, batchPrompt } = req.body;

    if (!category || !batchPrompt) {
      return res.status(400).json({ error: "Missing required category or batchPrompt parameter." });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are WonderBuild AI, an expert website template generator.
Output ONLY a valid JSON array matching the exact schema specified in the prompt.
No preamble, no markdown code block fences, no conversational text.
Ensure every template has 4-6 sections (hero, features/content, testimonials or social proof, pricing/CTA, footer).
Use camelCase CSS-in-JS style property names exclusively.
Ensure thumbnail URLs use unique random seed words.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: batchPrompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    const rawText = response.text || "[]";
    let templates = [];
    try {
      templates = JSON.parse(rawText.trim());
    } catch {
      const cleaned = rawText.replace(/```json/gi, "").replace(/```/g, "").trim();
      templates = JSON.parse(cleaned);
    }

    res.json({ success: true, count: Array.isArray(templates) ? templates.length : 0, templates });
  } catch (err: any) {
    console.error("Error generating batch with Gemini:", err);
    res.status(500).json({
      error: err.message || "Failed to generate templates with Gemini API.",
    });
  }
});

// 2. Search Grounding API (gemini-3.5-flash with Google Search tool)
app.post("/api/search-grounding", async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) {
      return res.status(400).json({ error: "Missing query parameter." });
    }

    const ai = getGeminiClient();

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Perform grounded search research for web design, template trends, and content related to: ${query}. Summarize key features, design best practices, layout structure, color schemes, and target audience expectations.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "";
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = rawChunks
      .filter((chunk: any) => chunk.web?.uri)
      .map((chunk: any) => ({
        title: chunk.web.title || chunk.web.uri,
        uri: chunk.web.uri,
      }));

    res.json({
      success: true,
      text,
      sources,
    });
  } catch (err: any) {
    console.error("Error in search-grounding:", err);
    res.status(500).json({ error: err.message || "Search grounding failed." });
  }
});

// 3. Image Generation & Editing API (gemini-3-pro-image or gemini-3.1-flash-image)
app.post("/api/generate-image", async (req, res) => {
  try {
    const {
      prompt,
      baseImage, // base64 data string if editing existing image
      aspectRatio = "16:9", // "1:1", "2:3", "3:2", "3:4", "4:3", "9:16", "16:9", "21:9"
      imageSize = "1K", // "1K", "2K", "4K"
      model = "gemini-3-pro-image",
    } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Missing image prompt." });
    }

    const ai = getGeminiClient();

    const parts: any[] = [];

    // If base image provided, add as inlineData for image editing
    if (baseImage) {
      const match = baseImage.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }

    parts.push({ text: prompt });

    const selectedModel = model || "gemini-3-pro-image";

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
          imageSize: imageSize as any,
        },
      },
    });

    let generatedImageUrl = null;
    let caption = "";

    const candidateParts = response.candidates?.[0]?.content?.parts || [];
    for (const part of candidateParts) {
      if (part.inlineData) {
        const mime = part.inlineData.mimeType || "image/png";
        generatedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
      } else if (part.text) {
        caption += part.text;
      }
    }

    if (!generatedImageUrl) {
      throw new Error("No image data returned from Gemini image model.");
    }

    res.json({
      success: true,
      imageUrl: generatedImageUrl,
      caption,
    });
  } catch (err: any) {
    console.error("Error generating/editing image:", err);
    res.status(500).json({ error: err.message || "Image generation failed." });
  }
});

// 4. Fast Micro-Task API (gemini-3.1-flash-lite)
app.post("/api/fast-task", async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Missing prompt." });
    }

    const ai = getGeminiClient();

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite",
      contents: `Context: ${context || "Web template micro-copy"}
Request: ${prompt}`,
      config: {
        temperature: 0.8,
      },
    });

    res.json({ success: true, result: response.text || "" });
  } catch (err: any) {
    console.error("Error in fast-task:", err);
    res.status(500).json({ error: err.message || "Fast task execution failed." });
  }
});

// 5. Complex Design & UX Audit API (gemini-3.1-pro-preview)
app.post("/api/complex-analysis", async (req, res) => {
  try {
    const { template } = req.body;
    if (!template) {
      return res.status(400).json({ error: "Missing template data." });
    }

    const ai = getGeminiClient();

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: `Perform a comprehensive UX, visual design, conversion rate, and accessibility audit for this website template JSON:
${JSON.stringify(template, null, 2)}

Provide output strictly in JSON format with keys:
"score" (number 1-100),
"strengths" (array of strings),
"recommendations" (array of actionable strings),
"headlineImprovements" (array of objects { original: string, suggested: string, reason: string })`,
      config: {
        responseMimeType: "application/json",
      },
    });

    const rawText = response.text || "{}";
    let analysis = {};
    try {
      analysis = JSON.parse(rawText.trim());
    } catch {
      const cleaned = rawText.replace(/```json/gi, "").replace(/```/g, "").trim();
      analysis = JSON.parse(cleaned);
    }

    res.json({ success: true, analysis });
  } catch (err: any) {
    console.error("Error in complex-analysis:", err);
    res.status(500).json({ error: err.message || "Complex analysis failed." });
  }
});

async function startServer() {
  const server = http.createServer(app);

  // Setup WebSocket Server for Gemini Live API Voice Conversation
  const wss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (request, socket, head) => {
    const pathname = request.url;
    if (pathname === "/live") {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit("connection", ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  wss.on("connection", async (clientWs: WebSocket) => {
    console.log("Client connected to /live WebSocket");
    let session: any = null;

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        clientWs.send(JSON.stringify({ error: "GEMINI_API_KEY is not set." }));
        clientWs.close();
        return;
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      session = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: "Zephyr" },
            },
          },
          systemInstruction:
            "You are WonderVoice Co-Pilot, an expert AI Web Design assistant for WonderBuild. Speak concisely, offer clear visual design suggestions, and help users construct modern web templates.",
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            const parts = message.serverContent?.modelTurn?.parts || [];
            for (const part of parts) {
              if (part.inlineData?.data) {
                clientWs.send(
                  JSON.stringify({
                    audio: part.inlineData.data,
                  })
                );
              }
              if (part.text) {
                clientWs.send(
                  JSON.stringify({
                    transcript: part.text,
                  })
                );
              }
            }

            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
          },
          onclose: () => {
            console.log("Gemini Live session closed");
          },
          onerror: (err) => {
            console.error("Gemini Live error:", err);
            clientWs.send(JSON.stringify({ error: err.message }));
          },
        },
      });

      clientWs.on("message", (data: any) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio && session) {
            session.sendRealtimeInput({
              audio: {
                data: parsed.audio,
                mimeType: "audio/pcm;rate=16000",
              },
            });
          } else if (parsed.text && session) {
            session.sendRealtimeInput({
              text: parsed.text,
            });
          }
        } catch (e) {
          console.error("Error processing client message:", e);
        }
      });

      clientWs.on("close", () => {
        if (session) {
          session.close();
        }
      });
    } catch (err: any) {
      console.error("Live WebSocket connection error:", err);
      clientWs.send(JSON.stringify({ error: err.message }));
      clientWs.close();
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`WonderBuild server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
