import React, { useState, useEffect } from 'react';
import {
  Folder,
  Film,
  Play,
  Pause,
  RotateCcw,
  Plus,
  Search,
  Grid,
  List,
  ChevronRight,
  ChevronDown,
  FileCode,
  Image as ImageIcon,
  Box,
  Sliders,
  Type,
  Aperture,
  Code,
  Layers
} from 'lucide-react';

interface BottomAssetPanelProps {
  onSelectAsset?: (assetName: string) => void;
}

export const BottomAssetPanel: React.FC<BottomAssetPanelProps> = ({ onSelectAsset }) => {
  const [activeTab, setActiveTab] = useState<'Inspect' | 'Animation' | 'Animator'>('Animation');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(28);
  const [searchTerm, setSearchTerm] = useState('');
  const [adventurerTreeOpen, setAdventurerTreeOpen] = useState(true);

  // Keyframes matching image diamonds
  const keyframes = [12, 28, 45, 62, 78];

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentFrame((prev) => (prev >= 100 ? 0 : prev + 1));
      }, 50);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const adventurerNodes = [
    'Camera',
    'Main',
    'Staff',
    'Climbing',
    'Kndana..pno_short.map',
    'Boots',
    'Boots',
    'Dlift',
    'Ninja_Dirt',
    'Ninja_Dle',
    'Ninja Idlt_Dirt_A',
    'Ninja Dirt_Dirt_B',
    'Rig_Adventurer_Lea_A',
    'Animation_Climb',
    'Animation_Idle',
  ];

  const assets = [
    { id: '1', name: 'Materials', type: 'folder', color: '#e2e8f0', icon: 'folder' },
    { id: '2', name: 'Testhija', type: 'folder', color: '#cbd5e1', icon: 'folder' },
    { id: '3', name: 'TestNinja', type: 'folder', color: '#cbd5e1', icon: 'folder' },
    { id: '4', name: 'Building_1', type: 'mesh', color: '#94a3b8', icon: 'mesh' },
    { id: '5', name: 'Building_2', type: 'mesh', color: '#94a3b8', icon: 'mesh' },
    { id: '6', name: 'Building_2', type: 'mesh', color: '#94a3b8', icon: 'mesh' },
    { id: '7', name: 'Terrain_1...', type: 'terrain', color: '#d97706', icon: 'terrain' },
    { id: '8', name: 'Terrain_Map', type: 'texture', color: '#06b6d4', icon: 'texture' },
    { id: '9', name: 'Light_Helo', type: 'texture', color: '#a855f7', icon: 'texture' },
    { id: '10', name: 'Asset_Ram', type: 'hex', color: '#eab308', icon: 'hex' },
    { id: '11', name: 'Rig_Adv..', type: 'rig', color: '#38bdf8', icon: 'rig' },
    { id: '12', name: 'Ninjcf..', type: 'code', color: '#f97316', icon: 'code' },
    { id: '13', name: 'Asset_Cf...', type: 'film', color: '#64748b', icon: 'film' },
    { id: '14', name: 'Ninja_Idle', type: 'anim', color: '#38bdf8', icon: 'cube' },
    { id: '15', name: 'Ninja_To...', type: 'pose', color: '#4ade80', icon: 'pose' },
    { id: '16', name: 'Aa Gpen_D...', type: 'font', color: '#f1f5f9', icon: 'font' },
    { id: '17', name: 'PostPh0...', type: 'color', color: '#ec4899', icon: 'aperture' },
    { id: '18', name: 'Reflecti...', type: 'material', color: '#cbd5e1', icon: 'sphere' },
    { id: '19', name: 'Reflecti...', type: 'material', color: '#94a3b8', icon: 'sphere' },
    { id: '20', name: 'Score_M...', type: 'unity', color: '#ffffff', icon: 'unity' },
    { id: '21', name: 'TwistT...', type: 'unity', color: '#ffffff', icon: 'unity' },
    { id: '22', name: 'TwoBtc...', type: 'script', color: '#3b82f6', icon: 'script' },
    { id: '23', name: 'Worksho...', type: 'tool', color: '#64748b', icon: 'tool' },
    { id: '24', name: 'Animation...', type: 'script', color: '#3b82f6', icon: 'script' },
  ];

  const renderAssetThumbnail = (asset: typeof assets[0]) => {
    switch (asset.icon) {
      case 'folder':
        return (
          <div className="w-8 h-8 rounded bg-[#2b303c] flex items-center justify-center border border-[#3b4252]">
            <Folder className="w-5 h-5 text-gray-200 fill-gray-200" />
          </div>
        );
      case 'mesh':
        return (
          <div className="w-8 h-8 rounded bg-[#1e232d] flex items-center justify-center border border-[#333a47]">
            <Box className="w-5 h-5 text-[#94a3b8]" />
          </div>
        );
      case 'texture':
        return (
          <div
            className="w-8 h-8 rounded border border-cyan-400/40 shadow-inner flex items-center justify-center"
            style={{ backgroundColor: asset.color }}
          >
            <div className="w-3 h-3 bg-white/30 rounded-full" />
          </div>
        );
      case 'hex':
        return (
          <div className="w-8 h-8 rounded bg-yellow-950/40 border border-yellow-500/50 flex items-center justify-center">
            <span className="text-yellow-400 font-bold text-xs">⬡</span>
          </div>
        );
      case 'rig':
        return (
          <div className="w-8 h-8 rounded bg-blue-950/40 border border-blue-400/50 flex items-center justify-center">
            <Box className="w-4 h-4 text-blue-400" />
          </div>
        );
      case 'code':
        return (
          <div className="w-8 h-8 rounded bg-orange-950/40 border border-orange-500/50 flex items-center justify-center">
            <Code className="w-4 h-4 text-orange-400" />
          </div>
        );
      case 'film':
        return (
          <div className="w-8 h-8 rounded bg-[#232731] border border-[#3c4454] flex items-center justify-center">
            <Film className="w-4 h-4 text-[#94a3b8]" />
          </div>
        );
      case 'cube':
        return (
          <div className="w-8 h-8 rounded bg-blue-600/30 border border-blue-500 flex items-center justify-center">
            <Box className="w-4 h-4 text-blue-300" />
          </div>
        );
      case 'pose':
        return (
          <div className="w-8 h-8 rounded bg-emerald-950/40 border border-emerald-500/50 flex items-center justify-center">
            <span className="text-emerald-400 text-xs font-bold">🧍</span>
          </div>
        );
      case 'font':
        return (
          <div className="w-8 h-8 rounded bg-[#2a2e38] border border-[#404756] flex items-center justify-center">
            <span className="text-white text-xs font-serif font-bold">Aa</span>
          </div>
        );
      case 'aperture':
        return (
          <div className="w-8 h-8 rounded bg-gradient-to-tr from-amber-500 via-pink-500 to-blue-500 p-0.5 flex items-center justify-center">
            <div className="w-full h-full bg-[#181a20] rounded flex items-center justify-center">
              <Aperture className="w-4 h-4 text-pink-400" />
            </div>
          </div>
        );
      case 'sphere':
        return (
          <div
            className="w-8 h-8 rounded-full border border-gray-400 shadow flex items-center justify-center overflow-hidden"
            style={{
              background: 'radial-gradient(circle at 35% 35%, #ffffff, #64748b, #0f172a)',
            }}
          />
        );
      case 'unity':
        return (
          <div className="w-8 h-8 rounded bg-[#282d38] border border-[#3b4252] flex items-center justify-center">
            <span className="text-white font-bold text-xs tracking-tighter">⚡</span>
          </div>
        );
      case 'script':
        return (
          <div className="w-8 h-8 rounded bg-blue-900/30 border border-blue-400/40 flex items-center justify-center">
            <span className="text-blue-300 font-mono font-bold text-xs">#</span>
          </div>
        );
      default:
        return (
          <div className="w-8 h-8 rounded bg-[#232731] border border-[#373e4d] flex items-center justify-center">
            <FileCode className="w-4 h-4 text-gray-400" />
          </div>
        );
    }
  };

  const filteredAssets = assets.filter((a) =>
    a.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-[218px] bg-[#1a1c22] border-t border-[#2d323c] flex flex-col select-none z-20 shrink-0">
      {/* Top Tabs Bar */}
      <div className="h-7 bg-[#21242b] border-b border-[#2d323c] px-3 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('Inspect')}
            className={`px-2 py-0.5 text-[11px] font-medium transition-colors ${
              activeTab === 'Inspect' ? 'bg-[#292e3a] text-white rounded' : 'text-[#9ca3af] hover:text-white'
            }`}
          >
            Inspect
          </button>
          <button
            onClick={() => setActiveTab('Animation')}
            className={`flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium transition-colors ${
              activeTab === 'Animation' ? 'bg-[#292e3a] text-white rounded' : 'text-[#9ca3af] hover:text-white'
            }`}
          >
            <Film className="w-3 h-3 text-blue-400" />
            <span>Animation</span>
          </button>
          <button
            onClick={() => setActiveTab('Animator')}
            className={`px-2 py-0.5 text-[11px] font-medium transition-colors ${
              activeTab === 'Animator' ? 'bg-[#292e3a] text-white rounded' : 'text-[#9ca3af] hover:text-white'
            }`}
          >
            🔀 Animator
          </button>

          <button className="text-[#9ca3af] hover:text-white px-1">
            <Plus className="w-3 h-3" />
          </button>
        </div>

        {/* Right Search in Asset Manager */}
        <div className="flex items-center gap-2">
          <div className="relative flex items-center">
            <Search className="w-3 h-3 text-[#64748b] absolute left-2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search assets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-[#14161a] text-[10.5px] text-[#cbd5e1] pl-6 pr-2 py-0.5 rounded border border-[#333947] focus:outline-none focus:border-blue-500 w-36"
            />
          </div>
          <span className="text-[10px] text-[#9ca3af] font-mono bg-[#282d38] px-1.5 py-0.5 rounded border border-[#373e4d]">
            18
          </span>
        </div>
      </div>

      {/* Center Asset Area (Left tree + Right Quick Access grid) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Tree Pane (Adventurer node list) */}
        <div className="w-48 bg-[#181a20] border-r border-[#2d323c] overflow-y-auto p-1.5 custom-scrollbar text-xs">
          <div
            onClick={() => setAdventurerTreeOpen(!adventurerTreeOpen)}
            className="flex items-center gap-1 text-[#cbd5e1] hover:text-white cursor-pointer py-0.5 px-1 rounded hover:bg-[#252832]"
          >
            {adventurerTreeOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            <Folder className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[11px] font-semibold">Adventurer</span>
          </div>

          {adventurerTreeOpen && (
            <div className="pl-3.5 space-y-0.5 mt-0.5">
              {adventurerNodes.map((node, i) => (
                <div
                  key={i}
                  className="flex items-center gap-1.5 text-[#9ca3af] hover:text-white hover:bg-[#222630] px-1.5 py-0.5 rounded cursor-pointer text-[10.5px] truncate"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500/60"></span>
                  <span className="truncate">{node}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Asset Grid Browser */}
        <div className="flex-1 bg-[#16181e] flex flex-col overflow-hidden">
          {/* Breadcrumb row */}
          <div className="px-3 py-1 bg-[#1d2027] border-b border-[#282c35] text-[11px] text-[#9ca3af] flex items-center gap-1">
            <span className="text-[#cbd5e1]">Assets</span>
            <ChevronRight className="w-3 h-3 text-[#64748b]" />
            <span className="text-blue-400 font-medium">Quick Access</span>
          </div>

          {/* Grid of cards */}
          <div className="flex-1 overflow-x-auto overflow-y-hidden p-2 flex items-center gap-2 custom-scrollbar">
            {filteredAssets.map((asset) => (
              <div
                key={asset.id}
                id={`asset-card-${asset.id}`}
                onClick={() => onSelectAsset && onSelectAsset(asset.name)}
                className="group w-[68px] h-[78px] bg-[#1e222a] hover:bg-[#282e3a] border border-[#2e3442] hover:border-blue-500/60 rounded flex flex-col items-center justify-between p-1.5 cursor-pointer transition-all shrink-0 active:scale-95"
              >
                <div className="flex-1 flex items-center justify-center">
                  {renderAssetThumbnail(asset)}
                </div>
                <span className="text-[9.5px] text-[#cbd5e1] group-hover:text-white truncate w-full text-center tracking-tight">
                  {asset.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline Track with Keyframe Diamond Markers */}
      <div className="h-8 bg-[#1f232b] border-t border-[#2d323c] px-3 flex items-center justify-between text-xs">
        {/* Playback Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-5 h-5 rounded bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow"
          >
            {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 fill-white ml-0.5" />}
          </button>
          <button
            onClick={() => setCurrentFrame(0)}
            className="text-[#9ca3af] hover:text-white p-0.5"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
          <span className="font-mono text-[10px] text-[#93c5fd] ml-1">
            F: {currentFrame} / 100
          </span>
        </div>

        {/* Timeline Bar with Diamond Keyframes */}
        <div className="flex-1 mx-4 relative h-3 bg-[#13151a] rounded flex items-center overflow-hidden border border-[#2b303c]">
          {/* Progress fill */}
          <div
            className="h-full bg-blue-900/40 border-r border-blue-400"
            style={{ width: `${currentFrame}%` }}
          />

          {/* Diamond Keyframe Markers (◆) as in image */}
          {keyframes.map((kf, index) => (
            <div
              key={index}
              style={{ left: `${kf}%` }}
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 cursor-pointer z-10"
              onClick={() => setCurrentFrame(kf)}
            >
              <div className="w-2.5 h-2.5 bg-[#f59e0b] rotate-45 border border-yellow-200 shadow-sm" />
            </div>
          ))}
        </div>

        <div className="text-[10px] text-[#64748b] font-mono">
          24 FPS (NTSC)
        </div>
      </div>
    </div>
  );
};
