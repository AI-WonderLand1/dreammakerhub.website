import React from 'react';
import { MousePointer2, Box, Sparkles, Paintbrush, Pipette, Ruler } from 'lucide-react';
import { ToolType } from '../types';

interface LeftToolDockProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
}

export const LeftToolDock: React.FC<LeftToolDockProps> = ({ activeTool, onSelectTool }) => {
  const tools = [
    {
      id: 'select' as ToolType,
      name: '+ Select Mode',
      icon: MousePointer2,
      description: 'Standard box & click selection',
      customIcon: null
    },
    {
      id: 'move' as ToolType, // Or Primitive
      name: '+ Add Box / Mesh',
      icon: Box,
      description: 'Add 3D Primitives & Objects',
      customIcon: null
    },
    {
      id: 'sculpt' as ToolType,
      name: '+ Sculpt Brush',
      icon: Sparkles,
      description: 'Deform geometry and organic mesh',
      customIcon: null
    },
    {
      id: 'paint' as ToolType,
      name: '+ Texture Paint',
      icon: Paintbrush,
      description: 'Paint directly on 3D textures',
      customIcon: null
    },
    {
      id: 'picker' as ToolType,
      name: '+ Material Picker',
      icon: Pipette,
      description: 'Sample BSDF shader values',
      customIcon: null
    },
    {
      id: 'measure' as ToolType,
      name: '+ Measure Distance',
      icon: Ruler,
      description: 'Spatial tape measure and dimension tool',
      customIcon: null
    },
  ];

  return (
    <aside className="w-[106px] bg-[#1a1c22] border-r border-[#2c3038] flex flex-col justify-between p-2 select-none z-10 shrink-0">
      {/* Top Label */}
      <div className="text-center">
        <span className="text-[10px] font-semibold text-[#8b929e] tracking-tight block">
          Left Tool Dock
        </span>
      </div>

      {/* Tools Vertical Stack */}
      <div className="flex flex-col gap-2 my-auto">
        {tools.map((tool) => {
          const Icon = tool.icon;
          const isActive = activeTool === tool.id;

          return (
            <button
              key={tool.id}
              id={`left-tool-${tool.id}`}
              onClick={() => onSelectTool(tool.id)}
              title={tool.description}
              className={`group flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-150 relative ${
                isActive
                  ? 'bg-[#2563eb] text-white shadow-lg shadow-blue-900/40 ring-1 ring-blue-400'
                  : 'bg-[#22252c] text-[#9ca3af] hover:text-white hover:bg-[#2a2e37] border border-[#2e333d]'
              }`}
            >
              <div className="w-8 h-8 rounded flex items-center justify-center mb-1">
                <Icon className={`w-5 h-5 transition-transform group-hover:scale-110 ${isActive ? 'text-white' : 'text-[#a0aec0]'}`} />
              </div>
              <span className="text-[9.5px] font-medium leading-tight text-center tracking-tight px-0.5">
                {tool.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Bottom Label */}
      <div className="text-center">
        <span className="text-[10px] font-semibold text-[#8b929e] tracking-tight block">
          Left Tool Dock
        </span>
      </div>
    </aside>
  );
};
