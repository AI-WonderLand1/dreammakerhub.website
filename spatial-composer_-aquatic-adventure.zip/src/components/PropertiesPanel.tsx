import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Sliders, Layers, Sparkles, Box, Palette } from 'lucide-react';
import { MaterialProperties, SceneObject } from '../types';

interface PropertiesPanelProps {
  selectedObject: SceneObject | undefined;
  materialProps: MaterialProperties;
  onUpdateMaterial: (key: keyof MaterialProperties, value: any) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  selectedObject,
  materialProps,
  onUpdateMaterial,
}) => {
  const [activeTab, setActiveTab] = useState<'Materials' | 'Animator' | 'Nodes' | 'Shones'>('Materials');
  const [transformOpen, setTransformOpen] = useState(true);

  const tabs = ['Materials', 'Materials', 'Animator', 'Nodes', 'Material', 'Shones'];

  return (
    <div className="flex-1 bg-[#1a1c22] flex flex-col select-none overflow-hidden min-h-[340px]">
      {/* Panel Header */}
      <div className="h-8 bg-[#21242b] border-b border-[#2d323c] px-3 flex items-center justify-between">
        <span className="text-xs font-semibold text-white tracking-wide">Properties</span>
      </div>

      {/* Transform Collapsible Bar */}
      <div
        onClick={() => setTransformOpen(!transformOpen)}
        className="px-3 py-1 bg-[#232730] border-b border-[#2d323c] flex items-center justify-between text-[11px] text-[#cbd5e1] cursor-pointer hover:text-white"
      >
        <div className="flex items-center gap-1 font-medium">
          {transformOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
          <span>Transform</span>
        </div>
        <span className="text-[10px] text-[#64748b]">World Space</span>
      </div>

      {/* Sub-Tabs Row */}
      <div className="flex items-center border-b border-[#2d323c] bg-[#1e2027] overflow-x-auto text-[11px]">
        {tabs.map((tab, idx) => (
          <button
            key={idx}
            onClick={() => setActiveTab(tab as any)}
            className={`px-2.5 py-1 text-[10.5px] font-medium whitespace-nowrap transition-colors border-r border-[#2d323c] ${
              idx === 0
                ? 'bg-[#282d38] text-white border-t-2 border-t-blue-500'
                : 'text-[#9ca3af] hover:text-white hover:bg-[#252832]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Material Parameters Inspector */}
      <div className="flex-1 overflow-y-auto p-3 text-[11px] space-y-2.5 custom-scrollbar relative">
        {/* Object Header with BSDF Badge */}
        <div className="flex items-center justify-between pb-1.5 border-b border-[#2d323c]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            <span className="font-semibold text-white text-[11.5px]">
              {selectedObject ? selectedObject.name.replace('Character: ', '') : 'Adventurer Girl'}
            </span>
          </div>
          <span className="bg-[#242936] text-[#93c5fd] px-1.5 py-0.5 rounded text-[10px] font-mono border border-[#3b4252]">
            BSDF
          </span>
        </div>

        {/* Shader Methods Selectors */}
        <div className="grid grid-cols-2 gap-2">
          <div className="flex flex-col">
            <select
              value={materialProps.method}
              onChange={(e) => onUpdateMaterial('method', e.target.value)}
              className="bg-[#232730] border border-[#343a47] rounded px-2 py-1 text-white text-[10.5px] focus:outline-none focus:border-blue-500"
            >
              <option value="GGX">GGX</option>
              <option value="Beckmann">Beckmann</option>
              <option value="Multiscatter GGX">Multiscatter GGX</option>
            </select>
          </div>

          <div className="flex flex-col">
            <select
              value={materialProps.algorithm}
              onChange={(e) => onUpdateMaterial('algorithm', e.target.value)}
              className="bg-[#232730] border border-[#343a47] rounded px-2 py-1 text-white text-[10.5px] focus:outline-none focus:border-blue-500"
            >
              <option value="Christensen-Burley">Christensen-Burley</option>
              <option value="Random Walk">Random Walk</option>
              <option value="Burley Diffusion">Burley Diffusion</option>
            </select>
          </div>
        </div>

        {/* Base Color & Texture */}
        <div className="flex items-center justify-between py-0.5">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
            <span className="text-[#cbd5e1] font-medium">Base Color</span>
          </div>
          <div className="flex items-center gap-1.5">
            <input
              type="color"
              value={materialProps.baseColor}
              onChange={(e) => onUpdateMaterial('baseColor', e.target.value)}
              className="w-5 h-5 rounded cursor-pointer bg-transparent border-0"
            />
            <span className="bg-[#242936] text-[#9ca3af] text-[10px] px-1.5 py-0.5 rounded border border-[#343a47]">
              Texture 0.000
            </span>
          </div>
        </div>

        {/* Subsurface Radius */}
        <div className="flex items-center justify-between py-0.5">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
            <span className="text-[#cbd5e1]">Subsurface Radius</span>
          </div>
          <span className="text-[#9ca3af] text-[10.5px]">0.000</span>
        </div>

        {/* Subsurface Color */}
        <div className="flex items-center justify-between py-0.5">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
            <span className="text-[#cbd5e1]">Subsurface Co</span>
          </div>
          <div className="w-16 h-3.5 bg-white rounded border border-[#4b5563]" />
        </div>

        {/* Metallic Slider */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Metallic</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.metallic.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.metallic}
            onChange={(e) => onUpdateMaterial('metallic', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Specular Slider */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Specular</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.specular.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.specular}
            onChange={(e) => onUpdateMaterial('specular', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Specular Tint Slider */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Specular Tint</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.specularTint.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.specularTint}
            onChange={(e) => onUpdateMaterial('specularTint', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Roughness Slider */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Roughness</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.roughness.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.roughness}
            onChange={(e) => onUpdateMaterial('roughness', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Anisotropic */}
        <div className="flex justify-between text-[#cbd5e1] text-[10.5px] py-0.5">
          <span>Anisotropic</span>
          <span className="text-[#9ca3af] font-mono">0.000</span>
        </div>

        {/* Anisotropic Rotation */}
        <div className="flex justify-between text-[#cbd5e1] text-[10.5px] py-0.5">
          <span>Anisotropic Rotation</span>
          <span className="text-[#9ca3af] font-mono">0.000</span>
        </div>

        {/* Sheen Slider */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Sheen</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.sheen.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.sheen}
            onChange={(e) => onUpdateMaterial('sheen', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Sheen Tint */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[#cbd5e1] text-[10.5px]">
            <span>Sheen Tint</span>
            <span className="text-[#93c5fd] font-mono">{materialProps.sheenTint.toFixed(3)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={materialProps.sheenTint}
            onChange={(e) => onUpdateMaterial('sheenTint', parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252a35] rounded-lg appearance-none cursor-pointer accent-[#2563eb]"
          />
        </div>

        {/* Clearcoat */}
        <div className="flex justify-between text-[#cbd5e1] text-[10.5px] py-0.5">
          <span>Clearcoat</span>
          <span className="text-[#9ca3af] font-mono">0.000</span>
        </div>

        {/* 3D Material Preview Sphere Thumbnail in Corner (As seen in image!) */}
        <div className="sticky bottom-0 right-0 flex justify-end pt-2">
          <div
            className="w-12 h-12 rounded-full border border-blue-400/60 shadow-xl overflow-hidden relative"
            style={{
              background: `radial-gradient(circle at 35% 35%, #ffffff 0%, ${materialProps.baseColor} 50%, #000000 100%)`,
              boxShadow: `0 0 15px rgba(56, 189, 248, 0.4)`,
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent" />
          </div>
        </div>
      </div>
    </div>
  );
};
