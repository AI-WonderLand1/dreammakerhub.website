import React from 'react';
import { MousePointer, Move, RotateCw, Scaling, ChevronDown } from 'lucide-react';
import { ToolType } from '../types';

interface TopToolShelfProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
  pivot: string;
  onPivotChange: (pivot: string) => void;
  snap: boolean;
  onSnapToggle: () => void;
  grid: string;
  onGridChange: (grid: string) => void;
}

export const TopToolShelf: React.FC<TopToolShelfProps> = ({
  activeTool,
  onSelectTool,
  pivot,
  onPivotChange,
  snap,
  onSnapToggle,
  grid,
  onGridChange,
}) => {
  return (
    <div className="h-9 bg-[#21242b] border-b border-[#2d323b] px-3 flex items-center justify-between text-xs select-none">
      {/* Left Transform Tools */}
      <div className="flex items-center gap-1.5">
        {/* Select Tool */}
        <button
          id="top-tool-select"
          onClick={() => onSelectTool('select')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
            activeTool === 'select'
              ? 'bg-[#2563eb] text-white shadow-sm ring-1 ring-blue-400/50'
              : 'text-[#9ca3af] hover:text-white hover:bg-[#2c313a]'
          }`}
        >
          <MousePointer className="w-3.5 h-3.5" />
          <span>+ Select</span>
        </button>

        {/* Move Tool */}
        <button
          id="top-tool-move"
          onClick={() => onSelectTool('move')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
            activeTool === 'move'
              ? 'bg-[#2563eb] text-white shadow-sm ring-1 ring-blue-400/50'
              : 'text-[#9ca3af] hover:text-white hover:bg-[#2c313a]'
          }`}
        >
          <Move className="w-3.5 h-3.5" />
          <span>+ Move</span>
        </button>

        {/* Rotate Tool */}
        <button
          id="top-tool-rotate"
          onClick={() => onSelectTool('rotate')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
            activeTool === 'rotate'
              ? 'bg-[#2563eb] text-white shadow-sm ring-1 ring-blue-400/50'
              : 'text-[#9ca3af] hover:text-white hover:bg-[#2c313a]'
          }`}
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span>↻ Rotate</span>
        </button>

        {/* Scale Tool */}
        <button
          id="top-tool-scale"
          onClick={() => onSelectTool('scale')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
            activeTool === 'scale'
              ? 'bg-[#2563eb] text-white shadow-sm ring-1 ring-blue-400/50'
              : 'text-[#9ca3af] hover:text-white hover:bg-[#2c313a]'
          }`}
        >
          <Scaling className="w-3.5 h-3.5" />
          <span>⬡ Scale</span>
        </button>

        <div className="h-4 w-[1px] bg-[#373c47] mx-1.5" />

        {/* Pivot Dropdown */}
        <div className="relative flex items-center">
          <select
            id="pivot-select"
            value={pivot}
            onChange={(e) => onPivotChange(e.target.value)}
            className="appearance-none bg-[#292d36] hover:bg-[#323742] text-[#d1d5db] hover:text-white text-[11px] pl-2 pr-5 py-1 rounded border border-[#39404d] cursor-pointer focus:outline-none"
          >
            <option value="Center">Pivot: Center</option>
            <option value="Bottom">Pivot: Bottom</option>
            <option value="Cursor">Pivot: 3D Cursor</option>
            <option value="Individual">Pivot: Individual</option>
          </select>
          <ChevronDown className="w-3 h-3 text-[#9ca3af] absolute right-1.5 pointer-events-none" />
        </div>

        {/* Snap Toggle */}
        <button
          id="snap-toggle"
          onClick={onSnapToggle}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] border border-[#39404d] transition-colors ${
            snap ? 'bg-[#2a374f] text-[#60a5fa] border-blue-500/40' : 'bg-[#292d36] text-[#9ca3af]'
          }`}
        >
          <span>Snap: {snap ? 'On' : 'Off'}</span>
          <ChevronDown className="w-3 h-3" />
        </button>

        {/* Grid Dropdown */}
        <div className="relative flex items-center">
          <select
            id="grid-select"
            value={grid}
            onChange={(e) => onGridChange(e.target.value)}
            className="appearance-none bg-[#292d36] hover:bg-[#323742] text-[#d1d5db] hover:text-white text-[11px] pl-2 pr-5 py-1 rounded border border-[#39404d] cursor-pointer focus:outline-none"
          >
            <option value="0.1m">Grid: 0.1m</option>
            <option value="0.5m">Grid: 0.5m</option>
            <option value="1m">Grid: 1m</option>
            <option value="5m">Grid: 5m</option>
          </select>
          <ChevronDown className="w-3 h-3 text-[#9ca3af] absolute right-1.5 pointer-events-none" />
        </div>
      </div>

      {/* Right Label */}
      <div className="text-[11px] font-medium text-[#8f96a3] tracking-tight">
        Top Tool Shelf
      </div>
    </div>
  );
};
