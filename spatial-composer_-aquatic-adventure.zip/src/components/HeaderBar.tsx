import React, { useState } from 'react';
import { ChevronDown, Sparkles, X, Check } from 'lucide-react';

interface HeaderBarProps {
  onTriggerAIAction?: (prompt: string) => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({ onTriggerAIAction }) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiStatus, setAiStatus] = useState<string | null>(null);

  const menuItems: Record<string, string[]> = {
    File: ['New Project', 'Open Project...', 'Save Scene (Ctrl+S)', 'Import Asset...', 'Export GLTF/USD', 'Preferences'],
    Edit: ['Undo (Ctrl+Z)', 'Redo (Ctrl+Y)', 'Duplicate (Shift+D)', 'Delete (X)', 'Select All (A)', 'Deselect (Alt+A)'],
    View: ['Frame Selected (Num .)', 'Toggle Quad View', 'Camera View (Num 0)', 'Top View (Num 7)', 'Front View (Num 1)', 'Show Gizmos'],
    Window: ['Toggle Fullscreen', 'New Workspace', 'Layout: Hybrid Aquatic', 'Reset Layout', 'Toggle Console'],
    Help: ['Spatial Composer Docs', 'Aquatic Project Tutorial', 'Shortcuts Sheet', 'About v4.1']
  };

  const handleAIExecute = () => {
    if (!aiPrompt.trim()) return;
    setAiStatus('Applying spatial command...');
    setTimeout(() => {
      if (onTriggerAIAction) {
        onTriggerAIAction(aiPrompt);
      }
      setAiStatus('Complete! Updated scene parameters.');
      setTimeout(() => {
        setAiStatus(null);
        setShowAIDialog(false);
        setAiPrompt('');
      }, 1200);
    }, 600);
  };

  return (
    <header className="h-11 bg-[#191b1f] border-b border-[#2d3139] flex items-center justify-between px-3 text-xs select-none relative z-50">
      {/* Left Title Area */}
      <div className="flex flex-col justify-center">
        <div className="flex items-center gap-2">
          <span className="font-bold tracking-wide text-white text-[13px] uppercase font-mono">
            SPATIAL COMPOSER: V.4.1 - HYBRID PROJECT: AQUATIC ADVENTURE
          </span>
        </div>
        <span className="text-[#8e94a0] text-[10px] tracking-normal font-sans leading-none -mt-0.5">
          Built according to the component layout map
        </span>
      </div>

      {/* Right Menu Bar + AI & Avatar */}
      <div className="flex items-center gap-4">
        {/* Menu Bar section */}
        <div className="flex flex-col items-center">
          <span className="text-[9px] text-[#6b7280] uppercase tracking-wider -mb-0.5">Menu Bar</span>
          <div className="flex items-center gap-1">
            {Object.keys(menuItems).map((menu) => (
              <div key={menu} className="relative">
                <button
                  id={`menu-btn-${menu.toLowerCase()}`}
                  onClick={() => setActiveMenu(activeMenu === menu ? null : menu)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    activeMenu === menu
                      ? 'bg-[#2b303c] text-white'
                      : 'text-[#d1d5db] hover:text-white hover:bg-[#252830]'
                  }`}
                >
                  {menu}
                </button>
                {activeMenu === menu && (
                  <div
                    className="absolute left-0 top-full mt-1 w-44 bg-[#1f2228] border border-[#373d49] rounded shadow-2xl py-1 z-50 text-left"
                    onMouseLeave={() => setActiveMenu(null)}
                  >
                    {menuItems[menu].map((sub, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveMenu(null)}
                        className="w-full text-left px-3 py-1.5 text-[11px] text-[#cbd5e1] hover:bg-[#333a48] hover:text-white flex items-center justify-between"
                      >
                        <span>{sub}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* AI Button */}
        <div className="relative">
          <button
            id="ai-assistant-btn"
            onClick={() => setShowAIDialog(!showAIDialog)}
            className="flex items-center gap-1 bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-2.5 py-1 rounded text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-200" />
            <span>AI</span>
            <ChevronDown className="w-3 h-3 text-blue-200" />
          </button>

          {/* AI Quick Dialog */}
          {showAIDialog && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-[#1b1e24] border border-[#3b4252] rounded-lg shadow-2xl p-3 z-50 text-left animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-2 border-b border-[#2e3440] mb-2">
                <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-blue-400" /> Spatial AI Copilot
                </span>
                <button
                  onClick={() => setShowAIDialog(false)}
                  className="text-[#64748b] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[10px] text-[#94a3b8] mb-2">
                Instruct the spatial engine to modify water lighting, add props, or adjust shader parameters.
              </p>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g. Enhance underwater caustics and turn lighting to deep bioluminescent blue..."
                className="w-full h-16 bg-[#111317] border border-[#333945] rounded p-2 text-white text-[11px] focus:outline-none focus:border-blue-500 resize-none"
              />
              <div className="mt-2 flex items-center justify-between">
                {aiStatus ? (
                  <span className="text-[10px] text-blue-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> {aiStatus}
                  </span>
                ) : (
                  <span className="text-[9px] text-[#64748b]">v4.1 Neural Engine</span>
                )}
                <button
                  onClick={handleAIExecute}
                  className="bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-medium px-3 py-1 rounded"
                >
                  Run
                </button>
              </div>
            </div>
          )}
        </div>

        {/* AI Avatar */}
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <div className="w-7 h-7 rounded-full p-[1.5px] bg-gradient-to-tr from-cyan-400 via-blue-500 to-indigo-500 flex items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                alt="AI Avatar"
                className="w-full h-full rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-green-500 border border-[#191b1f]"></span>
          </div>
          <span className="text-[10px] text-[#cbd5e1] font-medium leading-none">AI Avatar</span>
        </div>
      </div>
    </header>
  );
};
