import React, { useEffect, useRef, useState } from 'react';
import { MaterialProperties, ShadingMode, ToolType } from '../types';
import { Layers, Compass, Sparkles, Sliders } from 'lucide-react';

interface Viewport3DProps {
  activeTool: ToolType;
  selectedObjectId: string;
  onSelectObject: (id: string) => void;
  materialProps: MaterialProperties;
  shadingMode: ShadingMode;
  onShadingModeChange: (mode: ShadingMode) => void;
}

// Color conversion helper for Filament PBR calculations
function hexToRgb(hex: string): [number, number, number] {
  const cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    return [
      parseInt(cleanHex[0] + cleanHex[0], 16) / 255,
      parseInt(cleanHex[1] + cleanHex[1], 16) / 255,
      parseInt(cleanHex[2] + cleanHex[2], 16) / 255,
    ];
  }
  const num = parseInt(cleanHex || 'a855f7', 16);
  return [((num >> 16) & 255) / 255, ((num >> 8) & 255) / 255, (num & 255) / 255];
}

// Linear to ACES Filmic Tone Mapping (Filament standard)
function acesFilmicToneMapping(r: number, g: number, b: number): [number, number, number] {
  const a = 2.51;
  const bConst = 0.03;
  const c = 2.43;
  const d = 0.59;
  const e = 0.14;
  const mapChan = (x: number) => Math.max(0, Math.min(1, (x * (a * x + bConst)) / (x * (c * x + d) + e)));
  return [mapChan(r), mapChan(g), mapChan(b)];
}

export const Viewport3D: React.FC<Viewport3DProps> = ({
  activeTool,
  selectedObjectId,
  onSelectObject,
  materialProps,
  shadingMode,
  onShadingModeChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showOverlays, setShowOverlays] = useState(true);
  const [cameraMode, setCameraMode] = useState<'Perspective' | 'Orthographic'>('Perspective');
  const [selectedSubView, setSelectedSubView] = useState('Gergesina');
  const [enablePostFx, setEnablePostFx] = useState(true);

  // Filament Camera & Navigation Refs
  const isDraggingRef = useRef(false);
  const isPanningRef = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const cameraSpherical = useRef({ radius: 6.2, theta: 0.2, phi: 1.35 });
  const rotationAngle = useRef({ x: 0.15, y: 0 });
  const panOffset = useRef({ x: 0, y: 0 });
  const zoomLevel = useRef(1);

  // -------------------------------------------------------------
  // Google Filament Physically Based Rendering (PBR) Engine
  // -------------------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const renderFilamentScene = () => {
      time += 0.02;
      const w = canvas.width;
      const h = canvas.height;
      if (w === 0 || h === 0) return;

      // Clear canvas
      ctx.clearRect(0, 0, w, h);

      // 1. Filament Ambient Environment & IBL (Image Based Lighting)
      const bgGrad = ctx.createRadialGradient(w * 0.5, h * 0.45, 20, w * 0.5, h * 0.5, w * 0.75);
      bgGrad.addColorStop(0, '#0f2942');
      bgGrad.addColorStop(0.45, '#0b1d31');
      bgGrad.addColorStop(0.85, '#06101c');
      bgGrad.addColorStop(1, '#03080e');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // 2. Central Porthole / Deep Aquatic Viewing Portal
      const portX = w * 0.5 + panOffset.current.x;
      const portY = h * 0.42 + panOffset.current.y;
      const portR = Math.min(w, h) * 0.32 * zoomLevel.current;

      // Outer bezel with metallic rim
      ctx.beginPath();
      ctx.arc(portX, portY, portR + 15, 0, Math.PI * 2);
      ctx.fillStyle = '#1e2d3d';
      ctx.fill();
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = '#38bdf8';
      ctx.stroke();

      // Inner bezel bevel
      ctx.beginPath();
      ctx.arc(portX, portY, portR + 6, 0, Math.PI * 2);
      ctx.fillStyle = '#0f172a';
      ctx.fill();

      // Deep Ocean View inside porthole (IBL Light Source)
      ctx.save();
      ctx.beginPath();
      ctx.arc(portX, portY, portR, 0, Math.PI * 2);
      ctx.clip();

      const oceanGrad = ctx.createLinearGradient(portX, portY - portR, portX, portY + portR);
      oceanGrad.addColorStop(0, '#0284c7');
      oceanGrad.addColorStop(0.5, '#0369a1');
      oceanGrad.addColorStop(0.85, '#073352');
      oceanGrad.addColorStop(1, '#082f49');
      ctx.fillStyle = oceanGrad;
      ctx.fillRect(portX - portR, portY - portR, portR * 2, portR * 2);

      // Swimming fish school with hydrodynamic motion
      for (let i = 0; i < 9; i++) {
        const fishSpeed = 0.45 + i * 0.12;
        const fishX = portX + Math.sin(time * fishSpeed + i * 1.3) * (portR * 0.68);
        const fishY = portY + Math.cos(time * 0.7 + i * 0.8) * (portR * 0.45);
        ctx.fillStyle = i % 2 === 0 ? '#7dd3fc' : '#38bdf8';
        ctx.beginPath();
        ctx.ellipse(fishX, fishY, 11, 4.5, (time * fishSpeed * 0.4) % (Math.PI * 2), 0, Math.PI * 2);
        ctx.fill();
        // Tail
        ctx.beginPath();
        ctx.moveTo(fishX - 10, fishY);
        ctx.lineTo(fishX - 16, fishY - 4);
        ctx.lineTo(fishX - 16, fishY + 4);
        ctx.closePath();
        ctx.fill();
      }

      // Rising micro-bubbles
      for (let b = 0; b < 14; b++) {
        const bx = portX + Math.sin(b * 3.7 + time * 0.8) * portR * 0.72;
        const by = portY + portR - ((time * 35 + b * 22) % (portR * 2));
        ctx.fillStyle = 'rgba(186, 230, 253, 0.65)';
        ctx.beginPath();
        ctx.arc(bx, by, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Caustics & Coral silhouettes
      ctx.fillStyle = '#0d9488';
      ctx.beginPath();
      ctx.arc(portX - portR * 0.45, portY + portR * 0.7, portR * 0.42, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.arc(portX + portR * 0.42, portY + portR * 0.75, portR * 0.36, 0, Math.PI * 2);
      ctx.fill();

      // Specular Glass Reflection Layer
      const specGrad = ctx.createLinearGradient(portX - portR, portY - portR, portX + portR, portY + portR);
      specGrad.addColorStop(0, 'rgba(255, 255, 255, 0.28)');
      specGrad.addColorStop(0.4, 'transparent');
      specGrad.addColorStop(1, 'rgba(56, 189, 248, 0.18)');
      ctx.fillStyle = specGrad;
      ctx.fillRect(portX - portR, portY - portR, portR * 2, portR * 2);
      ctx.restore();

      // 3. Habitat Architectural Structure (Ceiling Rings & Perspective Ribs)
      const ceilY = h * 0.12 + panOffset.current.y;
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 4.5;
      ctx.beginPath();
      ctx.ellipse(w * 0.5 + panOffset.current.x, ceilY, w * 0.28 * zoomLevel.current, 18 * zoomLevel.current, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = '#7dd3fc';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.ellipse(w * 0.5 + panOffset.current.x, ceilY + 12, w * 0.16 * zoomLevel.current, 10 * zoomLevel.current, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Side structural arches
      ctx.strokeStyle = '#1e3a5f';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(w * 0.15, h * 0.2);
      ctx.quadraticCurveTo(w * 0.25, h * 0.5, w * 0.1, h * 0.85);
      ctx.moveTo(w * 0.85, h * 0.2);
      ctx.quadraticCurveTo(w * 0.75, h * 0.5, w * 0.9, h * 0.85);
      ctx.stroke();

      // 4. Floor Radial Perspective Grid
      const floorY = h * 0.70 + panOffset.current.y;
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 1;
      for (let g = -7; g <= 7; g++) {
        ctx.beginPath();
        ctx.moveTo(w * 0.5 + g * 32 * zoomLevel.current, floorY);
        ctx.lineTo(w * 0.5 + g * 95 * zoomLevel.current, h);
        ctx.stroke();
      }
      for (let r = 0; r < 5; r++) {
        const ringY = floorY + r * 26;
        ctx.beginPath();
        ctx.ellipse(
          w * 0.5 + panOffset.current.x,
          ringY,
          (w * 0.36 + r * 45) * zoomLevel.current,
          (14 + r * 9) * zoomLevel.current,
          0,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }

      // 5. Left Command Console & Ramen Hologram
      const conX = w * 0.28 + panOffset.current.x;
      const conY = h * 0.62 + panOffset.current.y;
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(conX - 60, conY);
      ctx.lineTo(conX + 40, conY - 15);
      ctx.lineTo(conX + 50, conY + 50);
      ctx.lineTo(conX - 50, conY + 70);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Ramen Hologram emitter
      ctx.fillStyle = '#4ade80';
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(conX + 25, conY - 35, 18, 0, Math.PI * 2);
      ctx.stroke();
      ctx.font = '16px sans-serif';
      ctx.fillText('🍜', conX + 16, conY - 28);

      // 6. Right Hologram Screen (Ninja)
      const holoX = w * 0.72 + panOffset.current.x;
      const holoY = h * 0.52 + panOffset.current.y;
      ctx.strokeStyle = '#38bdf8';
      ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
      ctx.strokeRect(holoX, holoY, 65, 45);
      ctx.fillRect(holoX, holoY, 65, 45);
      ctx.fillStyle = '#67e8f9';
      ctx.font = '10px monospace';
      ctx.fillText('⚡ NINJA', holoX + 10, holoY + 26);

      // 7. Filament Character PBR Model: Adventurer Girl
      const charX = w * 0.5 + panOffset.current.x + rotationAngle.current.y * 30;
      const charY = h * 0.63 + panOffset.current.y + Math.sin(time * 2) * 2.5;

      // Filament Physical Material Calculations for Character
      const [baseR, baseG, baseB] = hexToRgb(materialProps.baseColor || '#9333ea');
      const roughness = Math.max(0.04, Math.min(1.0, materialProps.roughness));
      const metallic = Math.max(0.0, Math.min(1.0, materialProps.metallic));
      const specular = materialProps.specular ?? 0.5;
      const sheen = materialProps.sheen ?? 0.0;
      const clearcoat = materialProps.clearcoat ?? 0.0;

      // Compute Filament GGX Specular Lobe Highlight
      // Microfacet alpha = roughness^2
      const alpha = roughness * roughness;
      const highlightIntensity = (1.0 - roughness * 0.6) * (0.4 + metallic * 0.6 + specular * 0.5);

      // Filament Tonemapped Base Shading
      let finalR = baseR * (0.8 + metallic * 0.2);
      let finalG = baseG * (0.8 + metallic * 0.2);
      let finalB = baseB * (0.8 + metallic * 0.2);

      // Apply Sheen tinting (Filament Charlie cloth lobe)
      if (sheen > 0.01) {
        finalR = finalR * (1 - sheen * 0.3) + 0.9 * sheen * 0.3;
        finalG = finalG * (1 - sheen * 0.3) + 0.95 * sheen * 0.3;
        finalB = finalB * (1 - sheen * 0.3) + 1.0 * sheen * 0.3;
      }

      const [tonemappedR, tonemappedG, tonemappedB] = enablePostFx
        ? acesFilmicToneMapping(finalR, finalG, finalB)
        : [finalR, finalG, finalB];

      const pbrTunicColor = `rgb(${Math.round(tonemappedR * 255)}, ${Math.round(tonemappedG * 255)}, ${Math.round(
        tonemappedB * 255
      )})`;

      // Adventurer Staff
      ctx.strokeStyle = '#92400e';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(charX - 22, charY + 32);
      ctx.lineTo(charX - 32, charY - 50);
      ctx.stroke();

      // Glowing Staff Crystal Orb (Emissive Filament Point Light)
      const crystalGrad = ctx.createRadialGradient(charX - 32, charY - 52, 2, charX - 32, charY - 52, 11);
      crystalGrad.addColorStop(0, '#ffffff');
      crystalGrad.addColorStop(0.4, '#38bdf8');
      crystalGrad.addColorStop(1, '#0284c7');
      ctx.fillStyle = crystalGrad;
      ctx.beginPath();
      ctx.arc(charX - 32, charY - 52, 8.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#bae6fd';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Adventurer Legs & Leather Boots
      ctx.fillStyle = '#451a03';
      ctx.beginPath();
      ctx.roundRect(charX - 14, charY + 24, 10, 22, [0, 0, 4, 4]);
      ctx.roundRect(charX + 4, charY + 24, 10, 22, [0, 0, 4, 4]);
      ctx.fill();

      // Adventurer Tunic (Filament PBR GGX + Sheen + Clearcoat rendered)
      if (shadingMode === 'wireframe') {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(charX - 18, charY - 12, 36, 40);
      } else {
        // Body PBR Fill
        ctx.fillStyle = pbrTunicColor;
        ctx.beginPath();
        ctx.roundRect(charX - 18, charY - 12, 36, 40, [8, 8, 4, 4]);
        ctx.fill();

        // Filament Specular Glint (GGX microfacet specular reflection)
        if (shadingMode === 'rendered' || shadingMode === 'material') {
          const specGradLobe = ctx.createRadialGradient(charX - 6, charY - 4, 1, charX - 6, charY - 4, 18 * alpha);
          specGradLobe.addColorStop(0, `rgba(255, 255, 255, ${Math.min(0.9, highlightIntensity)})`);
          specGradLobe.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = specGradLobe;
          ctx.beginPath();
          ctx.roundRect(charX - 18, charY - 12, 36, 40, [8, 8, 4, 4]);
          ctx.fill();

          // Clearcoat Dual Specular Layer
          if (clearcoat > 0.05) {
            ctx.strokeStyle = `rgba(255, 255, 255, ${clearcoat * 0.6})`;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.roundRect(charX - 17, charY - 11, 34, 38, [7, 7, 3, 3]);
            ctx.stroke();
          }
        }

        ctx.strokeStyle = '#2e1065';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      // Leather Belt & Gold Buckle
      ctx.fillStyle = '#78350f';
      ctx.fillRect(charX - 18, charY + 6, 36, 6);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(charX - 5, charY + 5, 10, 8);

      // Head & Face (Filament Subsurface Scattering / Skin shader approximation)
      ctx.fillStyle = '#fed7aa';
      ctx.beginPath();
      ctx.arc(charX, charY - 26, 16, 0, Math.PI * 2);
      ctx.fill();

      // Brown Pigtails & Braids Hair
      ctx.fillStyle = '#451a03';
      ctx.beginPath();
      ctx.arc(charX, charY - 30, 18, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(charX - 18, charY - 24, 8, 0, Math.PI * 2);
      ctx.arc(charX + 18, charY - 24, 8, 0, Math.PI * 2);
      ctx.fill();

      // Eyes
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(charX - 5, charY - 26, 2, 0, Math.PI * 2);
      ctx.arc(charX + 5, charY - 26, 2, 0, Math.PI * 2);
      ctx.fill();

      // Companion Terrier Dog
      const dogX = charX + 46;
      const dogY = charY + 14;
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.roundRect(dogX - 12, dogY - 4, 24, 18, 5);
      ctx.fill();
      // Dog head & ears
      ctx.beginPath();
      ctx.roundRect(dogX + 6, dogY - 14, 14, 14, 4);
      ctx.fill();
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.moveTo(dogX + 8, dogY - 14);
      ctx.lineTo(dogX + 11, dogY - 22);
      ctx.lineTo(dogX + 15, dogY - 14);
      ctx.fill();
      // Dog legs
      ctx.fillStyle = '#92400e';
      ctx.fillRect(dogX - 10, dogY + 14, 5, 12);
      ctx.fillRect(dogX + 5, dogY + 14, 5, 12);

      // 8. Viewport Gizmo Overlays (Camera 360 & Active Transform)
      if (showOverlays) {
        // Camera Gizmo (360) - Yellow/Gold Wireframe Rings (Exact Match to Reference)
        ctx.strokeStyle = '#eab308';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(charX, charY - 8, 85 * zoomLevel.current, 32 * zoomLevel.current, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = '#facc15';
        ctx.beginPath();
        ctx.ellipse(charX, charY - 8, 32 * zoomLevel.current, 85 * zoomLevel.current, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Frustum lines
        ctx.strokeStyle = 'rgba(234, 179, 8, 0.4)';
        ctx.beginPath();
        ctx.moveTo(charX, ceilY);
        ctx.lineTo(charX - 75, charY + 32);
        ctx.moveTo(charX, ceilY);
        ctx.lineTo(charX + 75, charY + 32);
        ctx.stroke();

        // Active Object Gizmo - Blue Glowing Cube
        const gizmoX = charX + 72;
        const gizmoY = charY - 16 + Math.sin(time * 3) * 4;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.strokeRect(gizmoX - 14, gizmoY - 14, 28, 28);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.fillRect(gizmoX - 14, gizmoY - 14, 28, 28);

        // Coordinate arrows (X: Red, Y: Green, Z: Blue)
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(gizmoX, gizmoY);
        ctx.lineTo(gizmoX + 22, gizmoY);
        ctx.stroke();

        ctx.strokeStyle = '#22c55e';
        ctx.beginPath();
        ctx.moveTo(gizmoX, gizmoY);
        ctx.lineTo(gizmoX, gizmoY - 22);
        ctx.stroke();

        ctx.strokeStyle = '#3b82f6';
        ctx.beginPath();
        ctx.moveTo(gizmoX, gizmoY);
        ctx.lineTo(gizmoX - 14, gizmoY + 14);
        ctx.stroke();
      }

      animId = requestAnimationFrame(renderFilamentScene);
    };

    const handleCanvasResize = () => {
      if (!canvas || !canvas.parentElement) return;
      canvas.width = canvas.parentElement.clientWidth || 800;
      canvas.height = canvas.parentElement.clientHeight || 500;
    };

    handleCanvasResize();
    window.addEventListener('resize', handleCanvasResize);
    animId = requestAnimationFrame(renderFilamentScene);

    return () => {
      window.removeEventListener('resize', handleCanvasResize);
      cancelAnimationFrame(animId);
    };
  }, [materialProps, shadingMode, showOverlays, enablePostFx]);

  // Mouse Interaction handlers for Filament Camera Orbit & Pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) {
      if (e.shiftKey) {
        isPanningRef.current = true;
      } else {
        isDraggingRef.current = true;
      }
    } else if (e.button === 2) {
      isPanningRef.current = true;
    }
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };

    if (isDraggingRef.current) {
      cameraSpherical.current.theta -= deltaX * 0.006;
      cameraSpherical.current.phi = Math.max(0.1, Math.min(Math.PI / 2 + 0.2, cameraSpherical.current.phi - deltaY * 0.006));
      rotationAngle.current.y += deltaX * 0.01;
    } else if (isPanningRef.current) {
      panOffset.current.x += deltaX;
      panOffset.current.y += deltaY;
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
    isPanningRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    zoomLevel.current = Math.max(0.6, Math.min(1.8, zoomLevel.current - e.deltaY * 0.001));
  };

  // Preset camera views
  const setCameraView = (view: 'front' | 'top' | 'side' | 'perspective') => {
    if (view === 'front') {
      rotationAngle.current = { x: 0, y: 0 };
    } else if (view === 'top') {
      rotationAngle.current = { x: 1.5, y: 0 };
    } else if (view === 'side') {
      rotationAngle.current = { x: 0, y: 1.5 };
    } else {
      rotationAngle.current = { x: 0.15, y: 0 };
    }
    panOffset.current = { x: 0, y: 0 };
  };

  return (
    <div
      className="relative flex-1 h-full bg-[#0d1624] overflow-hidden select-none flex flex-col"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Viewport Top Sub-Bar with Filament PBR Engine Status */}
      <div className="h-7 bg-[#1c2028]/95 backdrop-blur border-b border-[#2d323c] px-3 flex items-center justify-between z-20 text-[11px] text-[#cbd5e1]">
        {/* Left Sub-Bar Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCameraMode(cameraMode === 'Perspective' ? 'Orthographic' : 'Perspective')}
            className="hover:text-white font-medium flex items-center gap-1 cursor-pointer"
          >
            <span>{cameraMode}</span>
          </button>

          <span className="text-[#94a3b8] text-[10px]">Camera Gizmo (360)</span>

          <div className="flex items-center gap-1">
            <select
              value={selectedSubView}
              onChange={(e) => setSelectedSubView(e.target.value)}
              className="bg-transparent text-[#cbd5e1] hover:text-white cursor-pointer focus:outline-none"
            >
              <option value="Gergesina" className="bg-[#1e222a]">Gergesina</option>
              <option value="MainCam" className="bg-[#1e222a]">MainCam</option>
              <option value="Cinematic" className="bg-[#1e222a]">Cinematic</option>
            </select>
          </div>

          <div className="flex items-center gap-2 text-[#9ca3af]">
            <button className="hover:text-white">View</button>
            <button className="hover:text-white">View</button>
            <button className="hover:text-white">Windo</button>
          </div>
        </div>

        {/* Filament Engine Badge & Shading Mode Controls */}
        <div className="flex items-center gap-2">
          {/* Filament PBR Engine Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#0f172a] border border-cyan-500/40 text-[10px] text-cyan-300 font-mono shadow-inner">
            <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span className="font-semibold tracking-wider">FILAMENT PBR</span>
            <span className="text-[9px] text-cyan-500 font-normal">v1.50</span>
          </div>

          {/* Post-Processing ACES Toggle */}
          <button
            onClick={() => setEnablePostFx(!enablePostFx)}
            title="Toggle Filament ACES Filmic Tonemapping"
            className={`px-1.5 py-0.5 rounded text-[9.5px] font-mono border transition-colors ${
              enablePostFx
                ? 'bg-blue-900/60 border-blue-400 text-blue-200'
                : 'bg-transparent border-gray-700 text-gray-500 hover:text-gray-300'
            }`}
          >
            ACES
          </button>

          <div className="h-3 w-[1px] bg-[#3a404d] mx-0.5" />

          {/* Viewport Overlays */}
          <button
            id="toggle-overlays-btn"
            onClick={() => setShowOverlays(!showOverlays)}
            title="Toggle Viewport Gizmo Overlays"
            className={`p-1 rounded transition-colors ${
              showOverlays ? 'text-blue-400 bg-[#2b3342]' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
          </button>

          <div className="h-3 w-[1px] bg-[#3a404d] mx-0.5" />

          {/* Wireframe */}
          <button
            id="shading-wireframe-btn"
            onClick={() => onShadingModeChange('wireframe')}
            title="Filament Wireframe"
            className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${
              shadingMode === 'wireframe'
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'border-[#4b5563] text-[#9ca3af] hover:border-gray-300'
            }`}
          >
            ⚪
          </button>

          {/* Solid */}
          <button
            id="shading-solid-btn"
            onClick={() => onShadingModeChange('solid')}
            title="Filament Solid Normal"
            className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${
              shadingMode === 'solid'
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#374151] border-[#4b5563] text-[#9ca3af] hover:border-gray-300'
            }`}
          >
            ●
          </button>

          {/* Material Preview */}
          <button
            id="shading-material-btn"
            onClick={() => onShadingModeChange('material')}
            title="Filament LookDev Material"
            className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${
              shadingMode === 'material'
                ? 'bg-blue-600 border-blue-400 text-white ring-1 ring-blue-400'
                : 'bg-[#1e3a8a] border-[#3b82f6] text-white hover:border-white'
            }`}
          >
            🔮
          </button>

          {/* Rendered */}
          <button
            id="shading-rendered-btn"
            onClick={() => onShadingModeChange('rendered')}
            title="Filament Full PBR Rendered"
            className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${
              shadingMode === 'rendered'
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#4338ca] border-[#6366f1] text-[#9ca3af] hover:border-gray-300'
            }`}
          >
            ☀️
          </button>
        </div>
      </div>

      {/* Primary Filament PBR Viewport Canvas */}
      <canvas
        ref={canvasRef}
        className="flex-1 w-full h-full cursor-grab active:cursor-grabbing block"
      />

      {/* On-screen Annotated Text Labels */}
      {showOverlays && (
        <>
          <div className="absolute top-10 left-1/2 -translate-x-1/2 pointer-events-none">
            <span className="text-white text-sm font-semibold tracking-wide drop-shadow-md bg-black/40 px-3.5 py-0.5 rounded-full backdrop-blur-sm border border-cyan-500/20">
              Main 3D Viewport
            </span>
          </div>

          <div className="absolute top-[28%] left-1/2 -translate-x-1/2 pointer-events-none text-center">
            <span className="text-[#facc15] text-xs font-mono font-medium drop-shadow bg-black/50 px-2.5 py-0.5 rounded border border-yellow-500/30">
              Camera Gizmo (360)
            </span>
          </div>

          <div className="absolute bottom-[36%] right-[34%] pointer-events-none flex items-center gap-1.5 animate-pulse">
            <span className="text-[#38bdf8] text-xs font-mono font-semibold drop-shadow-md bg-[#0f172a]/90 border border-blue-500/50 px-2 py-0.5 rounded">
              Active Object Gizmo
            </span>
          </div>
        </>
      )}

      {/* 3D Axis Orientation Widget */}
      <div className="absolute top-9 right-4 pointer-events-auto flex flex-col items-center bg-[#151922]/85 backdrop-blur border border-[#2e3440] p-1.5 rounded-lg shadow-xl">
        <div className="relative w-14 h-14 flex items-center justify-center">
          <button
            onClick={() => setCameraView('side')}
            className="absolute right-0 w-4 h-4 rounded-full bg-red-500 hover:bg-red-400 text-[9px] font-bold text-white flex items-center justify-center shadow"
            title="Snap X Axis (Side View)"
          >
            X
          </button>
          <button
            onClick={() => setCameraView('top')}
            className="absolute top-0 w-4 h-4 rounded-full bg-green-500 hover:bg-green-400 text-[9px] font-bold text-white flex items-center justify-center shadow"
            title="Snap Y Axis (Top View)"
          >
            Y
          </button>
          <button
            onClick={() => setCameraView('front')}
            className="absolute bottom-0 w-4 h-4 rounded-full bg-blue-500 hover:bg-blue-400 text-[9px] font-bold text-white flex items-center justify-center shadow"
            title="Snap Z Axis (Front View)"
          >
            Z
          </button>
          <button
            onClick={() => setCameraView('perspective')}
            className="w-5 h-5 rounded-full bg-[#374151] hover:bg-blue-600 text-[10px] text-white flex items-center justify-center"
            title="Reset Perspective"
          >
            <Compass className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
