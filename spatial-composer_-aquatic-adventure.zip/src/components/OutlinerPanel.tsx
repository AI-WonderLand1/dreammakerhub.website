import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Search, Eye, EyeOff, Lock, Unlock, Folder, Monitor, User, Dog, Maximize2, Lightbulb, Waves, Globe, Mountain } from 'lucide-react';
import { SceneObject } from '../types';

interface OutlinerPanelProps {
  objects: SceneObject[];
  selectedObjectId: string;
  onSelectObject: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  onToggleLock: (id: string) => void;
}

export const OutlinerPanel: React.FC<OutlinerPanelProps> = ({
  objects,
  selectedObjectId,
  onSelectObject,
  onToggleVisibility,
  onToggleLock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [insideOpen, setInsideOpen] = useState(true);
  const [outsideOpen, setOutsideOpen] = useState(true);

  const getObjectIcon = (type: SceneObject['type']) => {
    switch (type) {
      case 'character':
        return <User className="w-3.5 h-3.5 text-blue-400" />;
      case 'npc':
        return <User className="w-3.5 h-3.5 text-purple-400" />;
      case 'accessory':
        return <Dog className="w-3.5 h-3.5 text-amber-400" />;
      case 'console':
        return <Monitor className="w-3.5 h-3.5 text-cyan-400" />;
      case 'environment':
        return <Maximize2 className="w-3.5 h-3.5 text-teal-400" />;
      case 'light':
        return <Lightbulb className="w-3.5 h-3.5 text-yellow-400" />;
      case 'ocean':
        return <Waves className="w-3.5 h-3.5 text-blue-500" />;
      case 'sky':
        return <Globe className="w-3.5 h-3.5 text-indigo-400" />;
      case 'terrain':
        return <Mountain className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <Folder className="w-3.5 h-3.5 text-gray-400" />;
    }
  };

  const insideObjects = objects.filter((o) => o.category === 'inside');
  const outsideObjects = objects.filter((o) => o.category === 'outside');

  const filteredInside = insideObjects.filter((o) =>
    o.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredOutside = outsideObjects.filter((o) =>
    o.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex-1 bg-[#1c1e24] flex flex-col border-b border-[#2d323c] select-none min-h-[220px]">
      {/* Panel Header */}
      <div className="h-8 bg-[#21242b] border-b border-[#2d323c] px-3 flex items-center justify-between">
        <span className="text-xs font-semibold text-white tracking-wide">Outliner</span>
        <div className="flex items-center gap-1.5">
          {/* Search bar with AI tag */}
          <div className="relative flex items-center">
            <Search className="w-3 h-3 text-[#6b7280] absolute left-1.5 pointer-events-none" />
            <input
              id="outliner-search"
              type="text"
              placeholder="AI..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-24 bg-[#14161a] text-[11px] text-[#cbd5e1] pl-6 pr-2 py-0.5 rounded border border-[#333844] focus:outline-none focus:w-32 focus:border-blue-500 transition-all placeholder-[#6b7280]"
            />
          </div>
        </div>
      </div>

      {/* Hierarchy Tree */}
      <div className="flex-1 overflow-y-auto p-1.5 text-xs font-sans space-y-0.5 custom-scrollbar">
        {/* Root Scene Node */}
        <div className="flex items-center gap-1.5 px-1 py-1 text-[#d1d5db] hover:bg-[#252830] rounded cursor-pointer">
          <ChevronDown className="w-3.5 h-3.5 text-[#9ca3af]" />
          <Folder className="w-3.5 h-3.5 text-yellow-500/90" />
          <span className="font-medium text-[11.5px]">Scene: Aquatic Habitat</span>
        </div>

        {/* Level 1: Inside Elements */}
        <div className="pl-3">
          <div
            onClick={() => setInsideOpen(!insideOpen)}
            className="flex items-center gap-1.5 px-1 py-1 text-[#9ca3af] hover:text-[#e5e7eb] hover:bg-[#252830] rounded cursor-pointer"
          >
            {insideOpen ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
            <Folder className="w-3.5 h-3.5 text-blue-400/80" />
            <span className="text-[11px] font-medium">Inside Elements</span>
          </div>

          {insideOpen && (
            <div className="pl-3 space-y-0.5">
              {filteredInside.map((obj) => {
                const isSelected = selectedObjectId === obj.id;
                return (
                  <div
                    key={obj.id}
                    id={`outliner-item-${obj.id}`}
                    onClick={() => onSelectObject(obj.id)}
                    className={`group flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#1d4ed8] text-white font-medium shadow-sm'
                        : 'text-[#cbd5e1] hover:bg-[#282d38]'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {getObjectIcon(obj.type)}
                      <span className="text-[11px] truncate">{obj.name}</span>
                    </div>

                    <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleVisibility(obj.id);
                        }}
                        className="hover:text-white p-0.5"
                      >
                        {obj.visible ? (
                          <Eye className="w-3 h-3" />
                        ) : (
                          <EyeOff className="w-3 h-3 text-red-400" />
                        )}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleLock(obj.id);
                        }}
                        className="hover:text-white p-0.5"
                      >
                        {obj.locked ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Unlock className="w-3 h-3 text-[#64748b]" />
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Level 1: Outside Elements */}
        <div className="pl-3">
          <div
            onClick={() => setOutsideOpen(!outsideOpen)}
            className="flex items-center gap-1.5 px-1 py-1 text-[#9ca3af] hover:text-[#e5e7eb] hover:bg-[#252830] rounded cursor-pointer"
          >
            {outsideOpen ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
            <Folder className="w-3.5 h-3.5 text-cyan-400/80" />
            <span className="text-[11px] font-medium">Outside Elements</span>
          </div>

          {outsideOpen && (
            <div className="pl-3 space-y-0.5">
              {filteredOutside.map((obj) => {
                const isSelected = selectedObjectId === obj.id;
                return (
                  <div
                    key={obj.id}
                    id={`outliner-item-${obj.id}`}
                    onClick={() => onSelectObject(obj.id)}
                    className={`group flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#1d4ed8] text-white font-medium shadow-sm'
                        : 'text-[#cbd5e1] hover:bg-[#282d38]'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {getObjectIcon(obj.type)}
                      <span className="text-[11px] truncate">{obj.name}</span>
                    </div>

                    <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleVisibility(obj.id);
                        }}
                        className="hover:text-white p-0.5"
                      >
                        {obj.visible ? (
                          <Eye className="w-3 h-3" />
                        ) : (
                          <EyeOff className="w-3 h-3 text-red-400" />
                        )}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleLock(obj.id);
                        }}
                        className="hover:text-white p-0.5"
                      >
                        {obj.locked ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Unlock className="w-3 h-3 text-[#64748b]" />
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
