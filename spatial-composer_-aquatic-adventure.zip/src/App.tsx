import React, { useState } from 'react';
import { HeaderBar } from './components/HeaderBar';
import { TopToolShelf } from './components/TopToolShelf';
import { LeftToolDock } from './components/LeftToolDock';
import { Viewport3D } from './components/Viewport3D';
import { OutlinerPanel } from './components/OutlinerPanel';
import { PropertiesPanel } from './components/PropertiesPanel';
import { BottomAssetPanel } from './components/BottomAssetPanel';
import { StatusBar } from './components/StatusBar';
import { MaterialProperties, SceneObject, ShadingMode, ToolType } from './types';

export default function App() {
  // Active Tool State
  const [activeTool, setActiveTool] = useState<ToolType>('select');
  const [pivot, setPivot] = useState('Center');
  const [snap, setSnap] = useState(true);
  const [grid, setGrid] = useState('1m');

  // Shading mode (Material preview active in screenshot)
  const [shadingMode, setShadingMode] = useState<ShadingMode>('material');

  // Scene Objects List matching the exact hierarchy in the image
  const [sceneObjects, setSceneObjects] = useState<SceneObject[]>([
    {
      id: 'cmd_console',
      name: 'Command Console',
      type: 'console',
      category: 'inside',
      icon: 'monitor',
      visible: true,
      locked: false,
    },
    {
      id: 'char_adventurer',
      name: 'Character: Adventurer Girl',
      type: 'character',
      category: 'inside',
      icon: 'user',
      visible: true,
      locked: false,
      selected: true,
    },
    {
      id: 'npc_ninja',
      name: 'NPC: Ninja',
      type: 'npc',
      category: 'inside',
      icon: 'user',
      visible: true,
      locked: false,
    },
    {
      id: 'acc_terrier',
      name: 'Accessory: Terrier Dog',
      type: 'accessory',
      category: 'inside',
      icon: 'dog',
      visible: true,
      locked: false,
    },
    {
      id: 'viewing_port',
      name: 'Viewing Port',
      type: 'environment',
      category: 'inside',
      icon: 'maximize',
      visible: true,
      locked: false,
    },
    {
      id: 'light_fixtures',
      name: 'Light Fixtures',
      type: 'light',
      category: 'inside',
      icon: 'lightbulb',
      visible: true,
      locked: false,
    },
    {
      id: 'ocean_floor',
      name: 'Ocean Floor',
      type: 'ocean',
      category: 'outside',
      icon: 'waves',
      visible: true,
      locked: false,
    },
    {
      id: 'skybox',
      name: 'Skybox',
      type: 'sky',
      category: 'outside',
      icon: 'globe',
      visible: true,
      locked: false,
    },
    {
      id: 'terrain',
      name: 'Terrain',
      type: 'terrain',
      category: 'outside',
      icon: 'mountain',
      visible: true,
      locked: false,
    },
  ]);

  const [selectedObjectId, setSelectedObjectId] = useState<string>('char_adventurer');

  // Exact Material Properties from screenshot (GGX, Christensen-Burley, Specular 0.555, Roughness 0.372, etc.)
  const [materialProps, setMaterialProps] = useState<MaterialProperties>({
    shaderType: 'BSDF',
    method: 'GGX',
    algorithm: 'Christensen-Burley',
    baseColor: '#a855f7',
    subsurfaceRadius: 0.0,
    subsurfaceColor: '#ffffff',
    metallic: 0.0,
    specular: 0.555,
    specularTint: 0.091,
    roughness: 0.372,
    anisotropic: 0.0,
    anisotropicRotation: 0.0,
    sheen: 0.168,
    sheenTint: 0.5,
    clearcoat: 0.0,
  });

  const handleUpdateMaterial = (key: keyof MaterialProperties, value: any) => {
    setMaterialProps((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleToggleVisibility = (id: string) => {
    setSceneObjects((prev) =>
      prev.map((item) => (item.id === id ? { ...item, visible: !item.visible } : item))
    );
  };

  const handleToggleLock = (id: string) => {
    setSceneObjects((prev) =>
      prev.map((item) => (item.id === id ? { ...item, locked: !item.locked } : item))
    );
  };

  const handleSelectObject = (id: string) => {
    setSelectedObjectId(id);
  };

  const handleAIAction = (prompt: string) => {
    if (prompt.toLowerCase().includes('blue') || prompt.toLowerCase().includes('water')) {
      setMaterialProps((prev) => ({
        ...prev,
        baseColor: '#0284c7',
        roughness: 0.15,
        metallic: 0.4,
        specular: 0.9,
      }));
    } else if (prompt.toLowerCase().includes('gold') || prompt.toLowerCase().includes('yellow')) {
      setMaterialProps((prev) => ({
        ...prev,
        baseColor: '#f59e0b',
        metallic: 0.85,
        roughness: 0.2,
      }));
    }
  };

  const selectedObject = sceneObjects.find((o) => o.id === selectedObjectId);

  return (
    <div className="w-screen h-screen flex flex-col bg-[#121418] text-[#e2e8f0] font-sans antialiased overflow-hidden select-none">
      {/* 1. Header Bar */}
      <HeaderBar onTriggerAIAction={handleAIAction} />

      {/* 2. Top Tool Shelf */}
      <TopToolShelf
        activeTool={activeTool}
        onSelectTool={setActiveTool}
        pivot={pivot}
        onPivotChange={setPivot}
        snap={snap}
        onSnapToggle={() => setSnap(!snap)}
        grid={grid}
        onGridChange={setGrid}
      />

      {/* 3. Main Center Workspace (Left Tool Dock + Viewport 3D + Right Outliner/Properties) */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Tool Dock */}
        <LeftToolDock activeTool={activeTool} onSelectTool={setActiveTool} />

        {/* Central 3D Viewport */}
        <Viewport3D
          activeTool={activeTool}
          selectedObjectId={selectedObjectId}
          onSelectObject={handleSelectObject}
          materialProps={materialProps}
          shadingMode={shadingMode}
          onShadingModeChange={setShadingMode}
        />

        {/* Right Panels (Outliner + Properties) */}
        <aside className="w-72 bg-[#1b1d23] border-l border-[#2d323c] flex flex-col shrink-0 overflow-hidden z-10">
          <OutlinerPanel
            objects={sceneObjects}
            selectedObjectId={selectedObjectId}
            onSelectObject={handleSelectObject}
            onToggleVisibility={handleToggleVisibility}
            onToggleLock={handleToggleLock}
          />

          <PropertiesPanel
            selectedObject={selectedObject}
            materialProps={materialProps}
            onUpdateMaterial={handleUpdateMaterial}
          />
        </aside>
      </div>

      {/* 4. Bottom Panel: Asset Browser & Timeline */}
      <BottomAssetPanel onSelectAsset={(name) => console.log('Selected asset:', name)} />

      {/* 5. Status Bar */}
      <StatusBar
        selectedObjectName={selectedObject?.name ? selectedObject.name.replace('Character: ', '') : 'Adventurer Girl'}
        verts={36789}
        edges={62341}
      />
    </div>
  );
}
