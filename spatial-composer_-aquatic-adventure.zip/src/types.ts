export type ToolType = 'select' | 'move' | 'rotate' | 'scale' | 'sculpt' | 'paint' | 'picker' | 'measure';

export type ShadingMode = 'wireframe' | 'solid' | 'material' | 'rendered';

export interface SceneObject {
  id: string;
  name: string;
  type: 'character' | 'npc' | 'accessory' | 'environment' | 'light' | 'console' | 'ocean' | 'sky' | 'terrain';
  category: 'inside' | 'outside';
  icon: string;
  visible: boolean;
  locked: boolean;
  selected?: boolean;
}

export interface MaterialProperties {
  shaderType: string;
  method: string;
  algorithm: string;
  baseColor: string;
  subsurfaceRadius: number;
  subsurfaceColor: string;
  metallic: number;
  specular: number;
  specularTint: number;
  roughness: number;
  anisotropic: number;
  anisotropicRotation: number;
  sheen: number;
  sheenTint: number;
  clearcoat: number;
}

export interface AssetNode {
  id: string;
  name: string;
  type: 'folder' | 'model' | 'texture' | 'material' | 'script' | 'anim' | 'unity' | 'text';
  iconType: string;
  color?: string;
}

export interface TimelineKeyframe {
  frame: number;
  selected?: boolean;
}
